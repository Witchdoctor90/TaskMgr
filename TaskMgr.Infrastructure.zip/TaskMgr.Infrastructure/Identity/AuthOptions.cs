namespace TaskMgr.Infrastructure.Identity;

public class AuthOptions
{
    public const string ISSUER = "TaskMgr.Server";
    public const string AUDIENCE = "TaskMgr.Client";
}