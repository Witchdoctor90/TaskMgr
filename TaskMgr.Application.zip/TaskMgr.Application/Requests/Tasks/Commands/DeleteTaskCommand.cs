using MediatR;
using TaskMgr.Application.Exceptions;
using TaskMgr.Application.Interfaces;
using TaskMgr.Domain.Entities;

namespace TaskMgr.Application.Requests.Tasks.Commands;

public class DeleteTaskCommand : IRequest<bool>
{
    public DeleteTaskCommand(Guid taskId, Guid userId)
    {
        TaskId = taskId;
        UserId = userId;
    }

    public Guid TaskId { get; set; }
    public Guid UserId { get; set; }
}

public class DeleteTaskCommandHandler : IRequestHandler<DeleteTaskCommand, bool>
{
    private readonly IRepository<TaskEntity> _repository;

    public DeleteTaskCommandHandler(IRepository<TaskEntity> repository)
    {
        this._repository = repository;
    }

    public async Task<bool> Handle(DeleteTaskCommand request, CancellationToken cancellationToken)
    {
        var entity = await _repository.GetByIdAsync(request.TaskId);
        if (entity == null) throw new TaskEntityNotFoundException(request.TaskId);
        if (entity.UserId != request.UserId) throw new UnauthorizedAccessException();

        await _repository.DeleteAsync(entity.Id);
        await _repository.SaveChangesAsync(cancellationToken);
        return true;
    }
}